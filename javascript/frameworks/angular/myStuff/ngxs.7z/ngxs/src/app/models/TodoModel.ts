export interface TodoModel {
  id: number;
  task : string;
  done: boolean;
}
