import {TodoModel} from "./TodoModel";

export interface TodoStateModel {
  items : TodoModel[];
}
