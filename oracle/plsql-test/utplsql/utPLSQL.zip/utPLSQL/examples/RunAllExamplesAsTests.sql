whenever sqlerror exit failure rollback
whenever oserror exit failure rollback

@@RunAllExamples.sql

